<?php

set_time_limit(0);
ini_set('memory_limit','1024M');

include "insert_masivo.php";

function procesarTXT($conexion,$tabla,$archivo,$ciclo,$formato,$carga_id){

$handle=fopen($archivo,"r");

if(!$handle){
die("No se pudo abrir el archivo TXT");
}

$encabezado=fgetcsv($handle,0,"|");

$col_entidad=-1;
$total_columnas = count($encabezado);

for($i=0;$i<$total_columnas;$i++){
if(trim($encabezado[$i])=="ENT_ADMINISTRATIVA"){
$col_entidad=$i;
break;
}
}

$bloque=[];
$contador=0;
$limite=5000;

$fila_id=0;
$entidad_global="";

$columnas_utiles = $total_columnas - 1;
$total_estimado = 0;

$insertados = 0;

while(($fila=fgetcsv($handle,0,"|"))!==false){

$fila_id++;
$total_estimado += $columnas_utiles;

$cv_cct = isset($fila[0]) ? str_replace("'","\'",$fila[0]) : '';

$entidad="";

if($col_entidad!=-1 && isset($fila[$col_entidad])){
$entidad=str_replace("'","\'",trim($fila[$col_entidad]));
}

if($entidad_global=="" && $entidad!=""){
$entidad_global=$entidad;
}

for($i=1;$i<$total_columnas;$i++){

$variable=trim($encabezado[$i]);
if($variable=="") continue;

$valor = isset($fila[$i]) ? str_replace("'","\'",$fila[$i]) : '';

$bloque[]="(
'$entidad',
'$ciclo',
'$formato',
'$cv_cct',
'$variable',
'$valor',
$carga_id,
$fila_id
)";

$contador++;

if($contador >= $limite){

insertarBloque($conexion,$tabla,$bloque,$carga_id);

$insertados += $contador;

/* 🔥 ACTUALIZAR PROGRESO + REGISTROS (POCAS VECES) */
$progreso = ($total_estimado > 0) ? round(($insertados / $total_estimado) * 100) : 0;

$conexion->query("
UPDATE cargas 
SET progreso=$progreso, registros=$insertados
WHERE id=$carga_id
");

$bloque=[];
$contador=0;

}

}

}

if(!empty($bloque)){
insertarBloque($conexion,$tabla,$bloque,$carga_id);
$insertados += $contador;
}

if($entidad_global!=""){
$conexion->query("UPDATE cargas SET entidad='$entidad_global' WHERE id=$carga_id");
}

$conexion->query("
UPDATE cargas 
SET progreso=100, registros=$insertados
WHERE id=$carga_id
");

fclose($handle);

}
?>