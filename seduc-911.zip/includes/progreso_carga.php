<?php

include "includes/conexion.php";

/* obtener ultima carga activa */

$sql="SELECT progreso, registros, estado 
FROM cargas 
ORDER BY id DESC 
LIMIT 1";

$res=$conexion->query($sql);

if(!$res || $res->num_rows == 0){
echo json_encode([
"progreso"=>0,
"registros"=>0,
"estado"=>"sin_datos"
]);
exit;
}

$row=$res->fetch_assoc();

echo json_encode([
"progreso" => (int)$row['progreso'],
"registros" => (int)$row['registros'],
"estado" => $row['estado']
]);

?>