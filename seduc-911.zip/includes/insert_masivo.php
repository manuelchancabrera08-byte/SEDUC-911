<?php

function insertarBloque($conexion,$tabla,$valores,$carga_id){

/* SI NO HAY DATOS NO INSERTAR */
if(empty($valores)) return;

/* 🔥 CONTAR REGISTROS REALES */
$cantidad = count($valores);

/* 🔥 REINDEXAR */
$valores = array_values($valores);

/* 🔥 CONSTRUIR QUERY */
$sql = "INSERT INTO `$tabla`
(entidad,ciclo,formato,cv_cct,variable,valor,cuestionario_id,fila_id)
VALUES " . implode(",", $valores);

/* 🔥 EJECUTAR */
$resultado = $conexion->query($sql);

/* 🔥 CONTROL DE ERROR */
if(!$resultado){

error_log("ERROR SQL: " . $conexion->error);
error_log("QUERY: " . substr($sql,0,1000));

die("Error al insertar bloque. Revisa el log.");

}

/* 🔥 LIMPIAR MEMORIA */
$valores = null;
unset($valores);
unset($sql);

}

?>