<?php

set_time_limit(0);
ini_set('memory_limit','1024M');

include "insert_masivo.php";

function procesarTXT($conexion,$tabla,$archivo,$ciclo,$formato,$carga_id){

$handle=fopen($archivo,"r");

if(!$handle){
die("No se pudo abrir el archivo TXT");
}

/* CONTAR LINEAS */

$total_lineas = 0;
while(fgets($handle)){
$total_lineas++;
}

rewind($handle);

$encabezado=fgetcsv($handle,0,"|");

/* detectar columna entidad */

$col_entidad=-1;

for($i=0;$i<count($encabezado);$i++){

$col=trim($encabezado[$i]);

if($col=="ENT_ADMINISTRATIVA"){
$col_entidad=$i;
break;
}

}

$bloque=[];
$contador=0;
$limite=1000;

$fila_id=0;

$entidad_global="";

while(($fila=fgetcsv($handle,0,"|"))!==false){

$fila_id++;

/* ACTUALIZAR PROGRESO CADA 50 FILAS */

if($fila_id % 50 == 0){

$progreso = round(($fila_id / $total_lineas) * 100);

$conexion->query("
UPDATE cargas 
SET progreso=$progreso
WHERE id=$carga_id
");

}

$cv_cct=$fila[0];

$entidad="";

if($col_entidad!=-1 && isset($fila[$col_entidad])){
$entidad=trim($fila[$col_entidad]);
}

if($entidad_global=="" && $entidad!=""){
$entidad_global=$entidad;
}

for($i=1;$i<count($encabezado);$i++){

$variable=trim($encabezado[$i]);

if($variable=="") continue;

$valor=isset($fila[$i])?$fila[$i]:"";

$valor=str_replace("'","\'",$valor);
$cv_cct=str_replace("'","\'",$cv_cct);
$entidad=str_replace("'","\'",$entidad);

$bloque[]="(
'$entidad',
'$ciclo',
'$formato',
'$cv_cct',
'$variable',
'$valor',
$carga_id,
$fila_id
)";

$contador++;

if($contador>=$limite){

insertarBloque($conexion,$tabla,$bloque);

$bloque=[];
$contador=0;

}

}

}

/* actualizar entidad */

if($entidad_global!=""){

$sql="UPDATE cargas 
SET entidad='$entidad_global'
WHERE id=$carga_id";

$conexion->query($sql);

}

if(!empty($bloque)){
insertarBloque($conexion,$tabla,$bloque);
}

/* MARCAR 100% */

$conexion->query("
UPDATE cargas 
SET progreso=100
WHERE id=$carga_id
");

fclose($handle);

}
?>