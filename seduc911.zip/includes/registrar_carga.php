<?php

// MODIFICADO: ahora registrarCarga trabaja con ciclo + formato + entidad
function registrarCarga($conexion,$ciclo,$formato,$archivo,$usuario,$entidad){

// MODIFICADO: evitar eliminar cargas de otros estados
$sql="DELETE FROM cargas
WHERE estado='procesando'
AND ciclo='$ciclo'
AND formato='$formato'
AND entidad='$entidad'";

$conexion->query($sql);

// MODIFICADO: se guarda la entidad desde el inicio
$sql = "INSERT INTO cargas
(ciclo,formato,archivo_original,usuario,estado,entidad)
VALUES
('$ciclo','$formato','$archivo','$usuario','procesando','$entidad')";

$conexion->query($sql);

return $conexion->insert_id;

}

?>