<?php

function insertarBloque($conexion,$tabla,$valores){

/* SI NO HAY DATOS NO INSERTAR */
if(empty($valores)) return;

/* CONSTRUIR QUERY */

$sql = "INSERT INTO `$tabla`
(entidad,ciclo,formato,cv_cct,variable,valor,cuestionario_id,fila_id)
VALUES ".implode(",",$valores);

/* EJECUTAR */

$resultado = $conexion->query($sql);

/* CONTROL DE ERROR */

if(!$resultado){

die("Error al insertar bloque: ".$conexion->error);

}

/* LIBERAR MEMORIA DEL BLOQUE */

unset($valores);

}

?>