<?php

include "includes/conexion.php";

/* obtener ultima carga activa */

$sql="SELECT progreso 
FROM cargas 
ORDER BY id DESC 
LIMIT 1";

$res=$conexion->query($sql);

$row=$res->fetch_assoc();

echo json_encode($row);

?>