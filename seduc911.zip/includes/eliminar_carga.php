<?php

function eliminarCarga($conexion,$ciclo,$formato,$entidad){

/* permitir procesos largos */
set_time_limit(0);

/* =========================
   TABLA SEGÚN CICLO
========================= */

$ciclo_tabla = str_replace("-","_",$ciclo);
$tabla = "datos_crudos_".$ciclo_tabla;


/* =========================
   ELIMINAR DATOS CRUDOS
========================= */

$sql = "DELETE FROM `$tabla`
WHERE ciclo=? 
AND formato=?
AND entidad=?";

$stmt = $conexion->prepare($sql);

if(!$stmt){
die("Error preparando DELETE datos_crudos: ".$conexion->error);
}

$stmt->bind_param("sss",$ciclo,$formato,$entidad);

if(!$stmt->execute()){
die("Error ejecutando DELETE datos_crudos: ".$stmt->error);
}

$stmt->close();


/* =========================
   ELIMINAR REGISTRO CARGA
========================= */

$sql2 = "DELETE FROM cargas
WHERE ciclo=? 
AND formato=?
AND entidad=?";

$stmt2 = $conexion->prepare($sql2);

if(!$stmt2){
die("Error preparando DELETE cargas: ".$conexion->error);
}

$stmt2->bind_param("sss",$ciclo,$formato,$entidad);

if(!$stmt2->execute()){
die("Error ejecutando DELETE cargas: ".$stmt2->error);
}

$stmt2->close();


/* =========================
   ELIMINAR VISTA
========================= */

$formato_vista = strtolower($formato);
$formato_vista = str_replace(" ","_",$formato_vista);

$vista = "vista_".$formato_vista."_".$ciclo_tabla;

$conexion->query("DROP VIEW IF EXISTS `$vista`");

}

?>