<?php

// MODIFICADO: ahora la validación considera ciclo + formato + entidad
function existeCarga($conexion,$ciclo,$formato,$entidad){

$sql="SELECT id,formato,ciclo,usuario,fecha_carga,entidad
FROM cargas 
WHERE ciclo=? 
AND formato=? 
AND entidad=?
AND estado='completo'
LIMIT 1";

$stmt=$conexion->prepare($sql);

if(!$stmt){
die("Error en SQL verificar_carga_existente: ".$conexion->error);
}

// MODIFICADO: ahora se envía también la entidad
$stmt->bind_param("sss",$ciclo,$formato,$entidad);

if(!$stmt->execute()){
die("Error ejecutando consulta verificar_carga_existente: ".$stmt->error);
}

$result=$stmt->get_result();

if($result->num_rows>0){

$data=$result->fetch_assoc();

$stmt->close();

return $data;

}

$stmt->close();

return false;

}

?>