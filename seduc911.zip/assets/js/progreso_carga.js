
document.addEventListener("DOMContentLoaded",function(){

const form = document.querySelector("form");

if(!form) return;

form.addEventListener("submit",function(){

let modal = document.getElementById("modalProgreso");

if(modal){

modal.style.display="flex";

simularProgreso();

}

});

});

function simularProgreso(){

let barra = document.getElementById("barraProgreso");
let texto = document.getElementById("textoProgreso");

let progreso = 0;

let etapas = [
"Validando archivo...",
"Preparando estructura...",
"Insertando registros...",
"Generando vista horizontal...",
"Finalizando carga..."
];

let etapaActual = 0;

let intervalo = setInterval(function(){

progreso += Math.random()*8;

if(progreso >= 95){
progreso = 95;
}

barra.style.width = progreso+"%";

if(etapaActual < etapas.length){

texto.innerText = etapas[etapaActual];

}

etapaActual++;

},1200);

}

